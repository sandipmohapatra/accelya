import org.hibernate.*;
import org.hibernate.cfg.*;
public class first
{
	public static void main(String args[])
	{
		Configuration cfg=new Configuration();
		SessionFactory sf=cfg.configure().buildSessionFactory();
		Session ss=sf.openSession();
		mypojo pojo=new mypojo();
		pojo.setRollno("d1234");
		pojo.setName("charan123");
		mypojo1 pojo1=new mypojo1();
		pojo1.setMarks(500);
		pojo1.setAddress("bangalore");
		Transaction tx=ss.beginTransaction();
		ss.update(pojo);
		ss.save(pojo1);
		tx.commit();
	}
}