public class mypojo
{
	String rollno,name,mypojo1;

	public String getRollno() {
		return rollno;
	}

	public void setRollno(String rollno) {
		this.rollno = rollno;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMypojo1() {
		return mypojo1;
	}

	public void setMypojo1(String mypojo1) {
		this.mypojo1 = mypojo1;
	}
}